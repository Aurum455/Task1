from django.apps import AppConfig


class Tasks1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tasks1'
